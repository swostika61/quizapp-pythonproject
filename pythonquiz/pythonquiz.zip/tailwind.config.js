/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    'authentication/templates/**/*.html',
    "quiz_app/templates/**/*.html",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

